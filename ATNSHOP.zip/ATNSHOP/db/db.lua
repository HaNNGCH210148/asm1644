// {name
// brand
// material
// image 
// quantity 
// price


// name
// brand
// color
// material
// size
// batteries
// }